#!/bin/sh

# display

# wifi
#nmcli device wifi connect bustahcrib password classyship310
nmcli device wifi connect dlink-75A0 password fcdbc09167

# touchpad
xinput set-prop "SynPS/2 Synaptics TouchPad" "libinput Natural Scrolling Enabled" 1

# rclone - mount google drive
rclone mount gdrive:/ /stuff/drive &

# doom emacs
#/usr/bin/emacs --daemon212