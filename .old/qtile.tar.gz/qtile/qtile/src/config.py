############################### MGD QTile Config ###############################
##### Author: Michael Davis (mdavis@parrsridge.com)
##### Date: 06/2022
##### Version: 2
##### Description: This is a modified qtile default config, copyright below
################################################################################
#
# Copyright (c): (2010) Aldo Cortesi * (2010,2014) dequis * (2012) Randall Ma
#                (2012-2014) Tycho Andersen * (2012) Craig Barnes
#                (2013) horsik * (2013) Tao Sauvage
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
################################################################################

import os
import subprocess
from libqtile import bar, layout, widget, hook, qtile
from libqtile.config import Click, Drag, Group, Key, KeyChord, Match, Screen
from libqtile.lazy import lazy
from libqtile.log_utils import logger

from metadata import *

logger.warning('loading MGD Config...')

@lazy.function
def activity_config (qtile):
    #qtile.cmd_simulate_keypress([my.mod], "4")
    qtile.cmd_spawn([MY.apps.editor,'-n', "%s/lxconfig/scripts/qtile/" % HOME_PATH])
    SLEEP()
    qtile.cmd_spawn([MY.apps.terminal, "-e", 'tail',  '-f',  '%s/.local/share/qtile/qtile.log' % HOME_PATH])
    SLEEP()
    qtile.cmd_spawn([MY.apps.browser, "-n", "http://docs.qtile.org/en/stable/"])

@lazy.function
def activity_1 (qtile):
    qtile.cmd_spawn(["/bin/firefox", "--new-window", 
            "-url", "https://www.tradingview.com/chart/BsjZDN9p/", 
            "-url", "https://trade.oanda.com/",
            "-uri", "https://www.tdameritrade.com/"
    ])
    SLEEP()
    qtile.cmd_spawn([MY.apps.terminal, "--working-directory", "%s/Dev/oanda" % HOME_PATH])
    SLEEP()
    qtile.cmd_spawn([MY.apps.fileManager, "/stuff/drive/Trading"])

# KEYS
kc = [MY.mod]
modKeys = [
    Key(kc, "h", lazy.layout.left(), desc="Move focus to left"),
    Key(kc, "j", lazy.layout.down(), desc="Move focus down"),
    Key(kc, "l", lazy.layout.right(), desc="Move focus to right"),
    Key(kc, "k", lazy.layout.up(), desc="Move focus up"),

    Key(kc, "space", lazy.next_layout(), desc="Toggle between layouts"),
    Key(kc, "Tab", lazy.layout.next(), desc="Move window focus to other window"),
    Key(kc, "n", lazy.layout.normalize(), desc="Reset all window sizes"),
    Key(kc, "r", lazy.spawncmd(), desc="Spawn a command using a prompt widget"),
    Key(kc, "x", lazy.window.kill(), desc="Kill focused window"),

    Key(kc, "q", lazy.spawn('rofi -show ssh'), desc="Launch Rofi - SSH"),
    Key(kc, "w", lazy.spawn('rofi -show run'), desc="Launch Rofi - Run"),
    Key(kc, "e", lazy.spawn('rofi -show window'), desc="Launch Rofi- Window"),
    Key(kc, "Return", lazy.spawn(MY.apps.terminal), desc="Launch terminal"),
    Key(kc, "backslash", lazy.spawn(MY.apps.browser), desc="Launch browser"),

    KeyChord(kc, "a", [
        Key([], "c", activity_config()),
        Key([], "1", activity_1(), desc="Run activity #1"),
    ],
    mode="Activity:"),
]

kc = [MY.mod, "shift"]
modshiftKeys = [
    Key(kc, "h", lazy.layout.shuffle_left(), desc="Move window left"),
    Key(kc, "l", lazy.layout.shuffle_right(), desc="Move window right"),
    Key(kc, "j", lazy.layout.shuffle_down(), desc="Move window down"),
    Key(kc, "k", lazy.layout.shuffle_up(), desc="Move window up"),

    Key(kc, "Return", lazy.spawn(MY.apps.editor), desc="Launch text editor"),
    Key(kc, "backslash", lazy.spawn(MY.apps.fileManager), desc="Launch file manager"),
]

kc = [MY.mod, "control"]
modcontrolKeys = [
    Key(kc, "h", lazy.layout.grow_left(), desc="Grow window left"),
    Key(kc, "l", lazy.layout.grow_right(), desc="Grow window right"),
    Key(kc, "j", lazy.layout.grow_down(), desc="Grow window down"),
    Key(kc, "k", lazy.layout.grow_up(), desc="Grow window up"),

    Key(kc, "r", lazy.reload_config(), desc="Reload the config"),
    Key(kc, "q", lazy.shutdown(), desc="Shutdown Qtile"),
]

mixer_cmd = "amixer -c 0 -q set"
blankKeys = [
    Key([], "XF86AudioRaiseVolume", lazy.spawn(mixer_cmd + " Master 2dB+")),
    Key([], "XF86AudioLowerVolume", lazy.spawn(mixer_cmd + " Master 2dB-")),
    Key([], "XF86AudioMute", lazy.spawn(mixer_cmd + " Master toggle")),
    Key([], "XF86MonBrightnessUp", lazy.spawn(f"brightnessctl -s set +{ BRIGHTNESS_STEP }")),
    Key([], "XF86MonBrightnessDown", lazy.spawn(f"brightnessctl -s set { BRIGHTNESS_STEP }-")),
    Key([], "Print", lazy.spawn(f"scrot { HOME_PATH }/Pictures/screenshots/"))
]

# A list of available commands that can be bound to keys can be found
# at https://docs.qtile.org/en/latest/manual/config/lazy.html
keys = []
keys.extend(modKeys)
keys.extend(modshiftKeys)
keys.extend(modcontrolKeys)
keys.extend(blankKeys)

# Load the group control keys in
groups = [Group(i) for i in "12347890"]
for i in groups:
    keys.extend([
        Key([MY.mod], i.name, lazy.group[i.name].toscreen(),
            desc="Switch to group {}".format(i.name)),
        Key([MY.mod, "shift"], i.name, lazy.window.togroup(i.name, switch_group=True),
            desc="Switch to & move focused window to group {}".format(i.name)),
        # Key([MY.mod, "shift"], i.name, lazy.window.togroup(i.name),
        #        desc="Move focused window to group {}".format(i.name)),
    ])


# LAYOUTS
layouts = [
    layout.Columns(border_focus_stack=["#d75f5f", "#8f3d3d"], margin=3),
    layout.Max(margin=3),
    # Try more layouts by unleashing below layouts.
    # layout.Stack(num_stacks=2),
    # layout.Bsp(),
    # layout.Matrix(),
    # layout.MonadTall(),
    # layout.MonadWide(),
    # layout.RatioTile(),
    # layout.Tile(),
    # layout.TreeTab(),
    # layout.VerticalTile(),
    # layout.Zoomy(),
]


### SCREENS & WIDGETS
widget_defaults = dict(
    font=MY.fonts['normal'],
    fontsize = 14,
    padding = 2,
    background=TASKBAR_BGCOLOR
)
extension_defaults = widget_defaults.copy()


# The left side of the taskbar
widgetsLeft = [
    SimpleSeperator(10),
    widget.Image(
        filename=ICONS_FOLDER + "/python-white.png",
        scale="False",
        #mouse_callbacks = {'Button1': lambda: qtile.cmd_spawn(myTerm)}
    ),
    SimpleSeperator(10),
    widget.GroupBox(
        font="Ubuntu Bold",
        fmt=MY.emojis['bullet'],
        fontsize=15,
        margin_y=2,
        margin_x=0,
        padding_y=4,
        padding_x=4,
        borderwidth=3,
        active=MY.colors['lights'][1],
        inactive=MY.colors['purple'],
        rounded=False,
        highlight_color=MY.colors['darks'][3],
        highlight_method="line",
        this_current_screen_border=MY.colors['blue'],
        this_screen_border=MY.colors['yellow'],
        other_current_screen_border=MY.colors['blue'],
        other_screen_border=MY.colors['yellow'],
        #foreground=MY.colors['darks'][3],
        background=TASKBAR_BGCOLOR
    ),
    widget.TextBox(
        text='|',
        font=MY.fonts['monospace'],
        background=TASKBAR_BGCOLOR,
        foreground='474747',
        padding=2,
        fontsize=14
    ),
    widget.CurrentLayoutIcon(
        custom_icon_paths=[ICONS_FOLDER],
        foreground=MY.colors['lights'][1],
        background=TASKBAR_BGCOLOR,
        padding=0,
        scale=0.7
    ),
    widget.CurrentLayout(
        foreground=MY.colors['lights'][1],
        background=TASKBAR_BGCOLOR,
        padding=5
    ),
    widget.TextBox(
        text='|',
        font=MY.fonts['monospace'],
        background=TASKBAR_BGCOLOR,
        foreground='474747',
        padding=2,
        fontsize=14
    ),
    widget.Prompt(),
    widget.Chord(
        chords_colors={
                "launch": ("#ff0000", "#ffffff"),
                },
        name_transform=lambda name: name.upper(),
    ),
    widget.WindowName(
        foreground=MY.colors['blue'],
        background=TASKBAR_BGCOLOR,
        padding=0
    ),
    widget.Systray(
        background=TASKBAR_BGCOLOR,
        padding=5
    ),
    SimpleSeperator(6),
]

# The right side of the taskbar
colorSwitcher = switcher(TASKBAR_BGCOLOR, MY.colors['darks'][3])
widgetsRight = TaskbarStack ([
    widget.Net(
        interface="wlan0",
        format='{down} ↓↑ {up}',
        foreground=MY.colors['lights'][1],
        background=next(colorSwitcher),
        padding=5
    ),
    widget.ThermalSensor(
        foreground=MY.colors['lights'][1],
        background=next(colorSwitcher),
        threshold=90,
        fmt='{}',
        padding=5
    ),
    #widget.Volume(update_interval=0.2, emoji=True),
    widget.CheckUpdates(
        update_interval=1800,
        font = MY.fonts['bold'],
        fontsize = 16,
        distro="Arch_checkupdates",
        display_format="%s {updates} " % MY.emojis['update'],
        foreground=MY.colors['lights'][1],
        colour_have_updates=MY.colors['lights'][1],
        colour_no_updates=MY.colors['lights'][1],
        mouse_callbacks = {'Button1': lambda: qtile.cmd_spawn(MY.apps.terminal + " -e sudo pacman -Syu")},
        padding=5,
        background=next(colorSwitcher),
    ),
    widget.Memory(
        foreground=MY.colors['lights'][1],
        background=next(colorSwitcher),
        #mouse_callbacks = {'Button1': lambda: qtile.cmd_spawn(myTerm + ' -e htop')},
        fmt='Mem: {}',
        padding=5,
        measure_mem = 'G',
    ),
    widget.Battery(
        #format="{percent:2.0%}",
        markup=True,
        background=next(colorSwitcher),
    ),
    widget.Volume(
        font="Noto Sans Symbols",
        foreground=MY.colors['lights'][1],
        background=next(colorSwitcher),
        #fmt='{} %s' % MY.emojis['volume-on'],
        emoji = True,
        padding=5
    ),
    widget.Clock(
        font=MY.fonts['bold'],
        foreground=MY.colors['lights'][1],
        background=next(colorSwitcher),
        format="%A, %B %d - %H:%M "
    ),
], MY.emojis['triangle-left'], TASKBAR_BGCOLOR).stack()

taskbar = bar.Bar(widgetsLeft + widgetsRight, opacity=0.7, size=22)

# SCREENS
screens = [
    Screen(
        top=taskbar,
        wallpaper=MY.wallpaper,
        wallpaper_mode='stretch',
    ),
    Screen(
        wallpaper=MY.wallpaper,
        wallpaper_mode='stretch',
    ),
]


# MOUSE BUTTON/MOVE BINDS
mouse = [
    Drag([MY.mod], "Button1", lazy.window.set_position_floating(),
         start=lazy.window.get_position()),
    Drag([MY.mod], "Button3", lazy.window.set_size_floating(),
         start=lazy.window.get_size()),
    Click([MY.mod], "Button2", lazy.window.bring_to_front()),
    Click([MY.mod, "shift"], "Button1", lazy.window.toggle_floating()),
]


# FLOATING RULES
floating_layout = layout.Floating(
    float_rules=[
        # Run the utility of `xprop` to see the wm class and name of an X client.
        *layout.Floating.default_float_rules,
        Match(wm_class="confirmreset"),  # gitk
        Match(wm_class="makebranch"),  # gitk
        Match(wm_class="maketag"),  # gitk
        Match(wm_class="ssh-askpass"),  # ssh-askpass
        Match(title="branchdialog"),  # gitk
        Match(title="pinentry"),  # GPG key password entry
    ]
)

# HOOKS
@hook.subscribe.startup
def autostart():
    home = os.path.expanduser('~/.config/qtile/autostart.sh')
    subprocess.run([home])

@hook.subscribe.startup_once
def autostart_once():
    pass


# MISCELLANEOUS SETTINGS
dgroups_key_binder = None
dgroups_app_rules = []  # type: list
follow_mouse_focus = True
bring_front_click = False
cursor_warp = False
#
auto_fullscreen = True
focus_on_window_activation = "smart"
reconfigure_screens = True
auto_minimize = True  # should apps be able to auto-minimize on blur?
wl_input_rules = None  # For Wayland - can be used to configure input devices

################################################################################
##### We choose LG3D to maximize irony: it is a 3D non-reparenting WM written
##### in java that happens to be on java's whitelist.
wmname = "LG3D"
################################################################################